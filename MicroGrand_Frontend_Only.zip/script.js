// Supabase login/signup connection placeholder
const supabaseUrl = 'https://YOUR_SUPABASE_URL.supabase.co'
const supabaseKey = 'YOUR_SUPABASE_ANON_KEY'
const supabase = supabase.createClient(supabaseUrl, supabaseKey)

async function signUp(event) {
  event.preventDefault()
  const email = document.getElementById('email').value
  const password = document.getElementById('password').value
  const { error } = await supabase.auth.signUp({ email, password })
  alert(error ? error.message : 'Signup successful!')
}

async function logIn(event) {
  event.preventDefault()
  const email = document.getElementById('email').value
  const password = document.getElementById('password').value
  const { error } = await supabase.auth.signInWithPassword({ email, password })
  alert(error ? error.message : 'Login successful!')
}